package com.globalipi.platform.controller;

import com.globalipi.platform.entity.IPFiling;
import com.globalipi.platform.entity.Patent;
import com.globalipi.platform.entity.Trademark;
import com.globalipi.platform.service.IPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ip")
@CrossOrigin(origins = "*")
public class IPController {
    
    @Autowired
    private IPService ipService;
    
    // Patent endpoints
    @GetMapping("/patents")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<Patent>> getAllPatents() {
        return ResponseEntity.ok(ipService.getAllPatents());
    }
    
    @GetMapping("/patents/{id}")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<Patent> getPatentById(@PathVariable Long id) {
        return ResponseEntity.ok(ipService.getPatentById(id));
    }
    
    @GetMapping("/patents/search")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<Patent>> searchPatents(@RequestParam String keyword) {
        return ResponseEntity.ok(ipService.searchPatents(keyword));
    }
    
    @GetMapping("/patents/country/{country}")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<Patent>> getPatentsByCountry(@PathVariable String country) {
        return ResponseEntity.ok(ipService.getPatentsByCountry(country));
    }
    
    // Trademark endpoints
    @GetMapping("/trademarks")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<Trademark>> getAllTrademarks() {
        return ResponseEntity.ok(ipService.getAllTrademarks());
    }
    
    @GetMapping("/trademarks/{id}")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<Trademark> getTrademarkById(@PathVariable Long id) {
        return ResponseEntity.ok(ipService.getTrademarkById(id));
    }
    
    @GetMapping("/trademarks/search")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<Trademark>> searchTrademarks(@RequestParam String keyword) {
        return ResponseEntity.ok(ipService.searchTrademarks(keyword));
    }
    
    // IP Filing endpoints
    @GetMapping("/filings")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<IPFiling>> getAllFilings() {
        return ResponseEntity.ok(ipService.getAllFilings());
    }
    
    @GetMapping("/filings/{id}")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<IPFiling> getFilingById(@PathVariable Long id) {
        return ResponseEntity.ok(ipService.getFilingById(id));
    }
    
    @PostMapping("/filings")
    @PreAuthorize("hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM')")
    public ResponseEntity<IPFiling> createFiling(@RequestBody IPFiling filing) {
        return ResponseEntity.ok(ipService.createFiling(filing));
    }
    
    @PutMapping("/filings/{id}/monitor")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<IPFiling> enableMonitoring(@PathVariable Long id) {
        return ResponseEntity.ok(ipService.enableMonitoring(id));
    }
    
    @GetMapping("/filings/search")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN') or hasRole('INNOVATOR') or hasRole('LAW_FIRM') or hasRole('R&D_TEAM')")
    public ResponseEntity<List<IPFiling>> searchFilings(@RequestParam String keyword) {
        return ResponseEntity.ok(ipService.searchFilings(keyword));
    }
}

