package com.globalipi.platform.repository;

import com.globalipi.platform.entity.MonitoringAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MonitoringAlertRepository extends JpaRepository<MonitoringAlert, Long> {
    
    List<MonitoringAlert> findByUserId(Integer userId);
    
    List<MonitoringAlert> findByUserIdAndIsReadFalse(Integer userId);
    
    List<MonitoringAlert> findByUserIdOrderByCreatedAtDesc(Integer userId);
}

