package com.globalipi.platform.repository;

import com.globalipi.platform.entity.Trademark;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TrademarkRepository extends JpaRepository<Trademark, Long> {
    
    Optional<Trademark> findByTrademarkNumber(String trademarkNumber);
    
    List<Trademark> findByCountry(String country);
    
    List<Trademark> findByStatus(String status);
    
    @Query("SELECT t FROM Trademark t WHERE t.markText LIKE %:keyword% OR t.description LIKE %:keyword%")
    List<Trademark> searchByKeyword(@Param("keyword") String keyword);
    
    @Query("SELECT t FROM Trademark t WHERE t.owner LIKE %:owner%")
    List<Trademark> findByOwner(@Param("owner") String owner);
}

