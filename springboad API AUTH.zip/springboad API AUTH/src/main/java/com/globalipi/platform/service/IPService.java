package com.globalipi.platform.service;

import com.globalipi.platform.entity.IPFiling;
import com.globalipi.platform.entity.Patent;
import com.globalipi.platform.entity.Trademark;
import com.globalipi.platform.repository.IPFilingRepository;
import com.globalipi.platform.repository.PatentRepository;
import com.globalipi.platform.repository.TrademarkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class IPService {
    
    @Autowired
    private PatentRepository patentRepository;
    
    @Autowired
    private TrademarkRepository trademarkRepository;
    
    @Autowired
    private IPFilingRepository ipFilingRepository;
    
    // Patent methods
    public List<Patent> getAllPatents() {
        return patentRepository.findAll();
    }
    
    public Patent getPatentById(Long id) {
        return patentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patent not found with id: " + id));
    }
    
    public List<Patent> searchPatents(String keyword) {
        return patentRepository.searchByKeyword(keyword);
    }
    
    public List<Patent> getPatentsByCountry(String country) {
        return patentRepository.findByCountry(country);
    }
    
    // Trademark methods
    public List<Trademark> getAllTrademarks() {
        return trademarkRepository.findAll();
    }
    
    public Trademark getTrademarkById(Long id) {
        return trademarkRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trademark not found with id: " + id));
    }
    
    public List<Trademark> searchTrademarks(String keyword) {
        return trademarkRepository.searchByKeyword(keyword);
    }
    
    // IP Filing methods
    public List<IPFiling> getAllFilings() {
        return ipFilingRepository.findAll();
    }
    
    public IPFiling getFilingById(Long id) {
        return ipFilingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("IP Filing not found with id: " + id));
    }
    
    public IPFiling createFiling(IPFiling filing) {
        return ipFilingRepository.save(filing);
    }
    
    public IPFiling enableMonitoring(Long id) {
        IPFiling filing = getFilingById(id);
        filing.setMonitoringEnabled(true);
        return ipFilingRepository.save(filing);
    }
    
    public List<IPFiling> searchFilings(String keyword) {
        return ipFilingRepository.searchByKeyword(keyword);
    }
}

