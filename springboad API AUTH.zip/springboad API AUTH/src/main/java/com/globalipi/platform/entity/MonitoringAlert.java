package com.globalipi.platform.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "monitoring_alerts")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MonitoringAlert {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "user_id", nullable = false)
    private Integer userId;
    
    @Column(name = "ip_filing_id")
    private Long ipFilingId;
    
    @Column(length = 100)
    private String alertType; // STATUS_CHANGE, DEADLINE_APPROACHING, NEW_FILING, OPPOSITION
    
    @Column(length = 200)
    private String title;
    
    @Column(columnDefinition = "TEXT")
    private String message;
    
    @Column(name = "is_read")
    private Boolean isRead = false;
    
    @Column(name = "priority", length = 20)
    private String priority; // LOW, MEDIUM, HIGH, CRITICAL
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}

