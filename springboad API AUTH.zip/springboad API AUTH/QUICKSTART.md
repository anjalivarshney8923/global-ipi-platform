# Quick Start Guide

## Prerequisites Check
- [ ] Java 17+ installed (`java -version`)
- [ ] Maven installed (`mvn -version`)
- [ ] MySQL running and accessible

## Setup Steps

1. **Configure Database** (edit `src/main/resources/application.properties`):
   ```properties
   spring.datasource.username=your_mysql_username
   spring.datasource.password=your_mysql_password
   ```

2. **Build the Project**:
   ```bash
   mvn clean install
   ```

3. **Run the Application**:
   ```bash
   mvn spring-boot:run
   ```

4. **Test the API**:
   - Register: `POST http://localhost:8080/api/auth/register`
   - Login: `POST http://localhost:8080/api/auth/login`

## Git Push to GitHub

```bash
git add .
git commit -m "Initial commit: Spring Boot API with JWT Authentication"
git remote add origin <your-github-repo-url>
git branch -M main
git push -u origin main
```


